#include<bits/stdc++.h>
using namespace std;
#define Max 10005
#define pb push_back
vector<int>edge[Max];
int discv[Max];
int parent[Max];
int low[Max];
bool vis[Max];
bool AP[Max];
int tim;

void SetValue()
{
    for(int i=0;i<=Max;i++){
        parent[i] = -1;
        edge[i].clear();
        vis[i]=AP[i]=false;
        low[i]=0;
    }
    tim=0;
}
void dfs(int u)
{
    vis[u]=true;

    discv[u]=low[u] = (++tim);

    int child = 0;
    for(int i=0;i<edge[u].size();i++)
    {
        int v = edge[u][i];
        if(v==parent[u]) continue;

        if(!vis[v]){

            child++;
            parent[v] = u;

            dfs(v);

            low[u] = min(low[v],low[u]);

            if(parent[u]!=-1 and low[v]>=discv[u]){
                AP[u]=true;
            }
            if(parent[u]==-1 and child>1){
                AP[u]=true;
            }
        }

        low[u] = min(low[u],discv[v]);
    }
}

int main()
{
    int t;
    int cas=1;
    scanf("%d",&t);
    int n,m;
    while(t--){
        SetValue();
        scanf("%d%d",&n,&m);
        int u,v;
        for(int i=0;i<m;i++){
            scanf("%d%d",&u,&v);

            u--;v--;
            edge[u].pb(v);
            edge[v].pb(u);
        }

        for(int i=0;i<n;i++){
            if(!vis[i]){
                dfs(i);
            }
        }

        int cnt=0;
        for(int i=0;i<n;i++){
            if(AP[i]==true){
                //cout<<i+1<<' ';
                cnt++;
            }
        }
        //cout<<endl;
        cout<<"Case "<<cas++<": "<<cnt<<endl;
    }
}

/*
9 11
1 2
2 7
2 8
7 4
8 4
1 3
3 5
3 6
5 9
6 9
1 4
1 3
Ans : 1, 3
*/
