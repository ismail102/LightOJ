#include<bits/stdc++.h>
using namespace std;
int Grundy[10005];
int pile[10005];
bool vis[10005];
int calculateMex(set<int>Set)
{
    int Mex = 0;
    while(Set.find(Mex) != Set.end()) Mex++;
    return Mex;
}
int calculateGrundy(int n)
{
    
    
    Grundy[1] = 0;
    
    
    if(n==1) return 0;

    if(Grundy[n] != -1) return Grundy[n];

    set<int>Set;
    
    int m = n/2;
    for(int i=1;i<=m;i++){
        Set.insert(calculateGrundy(n-i));
    }

    Grundy[n] = calculateMex(Set);

    return Grundy[n];
}
int main()
{
    memset(Grundy, -1, sizeof(Grundy));

    //Grundy[100] = calculateGrundy(100);


    //for(int i=1;i<=100;i++) cout<<i<<"==>"<<Grundy[i]<<endl;;

    int t,cas=1;
    scanf("%d",&t);

    while(t--){
        int n;
        scanf("%d",&n);
        int Xor = 0;
        for(int i=0;i<n;i++){
            scanf("%d",&pile[i]);
            int N = pile[i];
            while(N%2) N/=2;
            Xor = Xor ^ (N/2);
        }
        //cout<<Xor<<endl;
        printf("Case %d: ",cas++);
        if(Xor>0) printf("Alice\n");
        else printf("Bob\n");
    }
    return 0;
}
