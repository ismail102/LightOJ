#include<bits/stdc++.h>
using namespace std;
int Grundy[10005];
int pile[10005];
bool vis[10005];
