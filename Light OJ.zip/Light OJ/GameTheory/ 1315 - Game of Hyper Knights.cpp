#include<bits/stdc++.h>
using namespace std;

int dx[]={+1,-1,-1,-2,-3,-2};
int dy[]={-2,-3,-2,-1,-1,+1};

int Grid[600][600];
int grundy[600][600];
int calculateMex(set<int>Set)
{
    int Mex = 0;
    while(Set.find(Mex) != Set.end()) Mex++;
    return Mex;
}

int calculateGrundy(int x,int y)
{

    if(grundy[x][y] != -1) return grundy[x][y];

    set<int>Set;
    for(int i=0;i<6;i++){

        int tx = x + dx[i];
        int ty = y + dy[i];

        if(tx<600 and tx>=0 and ty<600 and ty>=0){
            Set.insert(calculateGrundy(tx,ty));
        }
        else{
            grundy[x][y] = 0;
          
        }
    }

    grundy[x][y] = calculateMex(Set);

    return grundy[x][y];

}
int main()
{
    memset(grundy,-1,sizeof(grundy));

    for(int i=0;i<600;i++){
        for(int j=0;j<600;j++){
            grundy[i][j] = calculateGrundy(i,j);
        }
    }

    int n,t,cas=1;
    scanf("%d",&t);

    while(t--){

        

        int n;
        int x,y;
        int Xor = 0;
        scanf("%d",&n);

        for(int i=0;i<n;i++){
            scanf("%d%d",&x,&y);
            Xor = Xor ^ grundy[x][y];
        }
        if(Xor>0) printf("Case %d: Alice\n",cas++);
        else printf("Case %d: Bob\n",cas++);
    }
    return 0;
}