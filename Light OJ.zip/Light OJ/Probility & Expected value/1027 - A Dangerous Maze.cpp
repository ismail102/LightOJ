///    Author: Ismail Hossain
///    Univarsity: Chittagong University of Engineering Annd Technology
///    Uva:ISMAIL_HOSSAIN
///    Codeforces: ISMAIL_HOSSAIN
///    Facebook: Smile Mukul
 
///বিসমিল্লাহির  রাহমানির রাহিম
#include<bits/stdc++.h>
#define sf              scanf
#define pf              print
#define dd              double
#define fr              first
#define sc              second
#define pb              push_back
#define MP              make_pair
#define ll              long long
#define PI              acos(-1.0)
#define vci             vector<ll>
#define pll             pair<ll, ll>
#define vcc             vector<char>
#define sz(a)           (a.size())
#define pii             pair<int, int>
#define vcs             vector<string>
#define sf              scanf
#define read(a)         scanf("%d",&a)
#define readI1(a)       scanf("%I64d",&a)
#define read2(a,b)      scanf("%d%d",&a,&b)
#define FOR(i, s, e)    for(ll i=s; i<e; i++)
#define read3(a,b,c)    scanf("%d%d%d",&a,&b,&c)
#define readI2(a,b)     scanf("%I64d %I64d",&a,&b)
#define mem(a, b)       memset(a, b, sizeof(a))
#define readI3(a,b,C)   scanf("%I64d %I64d %I64d",&a,&b,&c)
#define open()          freopen("input.txt", "r", stdin)
#define show()          freopen("output.txt", "w", stdout)
#define bit(a) __builtin_popcount(a)
#define Max 1000005
#define inf INFINITY
using namespace std;
int Set(int n,int pos){ return n = (n | (1<<pos));}
bool check(int n,int pos){return (bool)(n & (1<<pos));}
int clearr(int n,int pos){return n = (n & ~(1<<pos));}
int update(int n,int pos){return n = (n ^ (1<<pos));}
int sz,base,M;
int A[105];
 
int main()
{
 
   int n;
   int t,cas=1;
   scanf("%d",&t);
   while(t--){
     scanf("%d",&n);
     int cnt=0,sum=0;
     for(int i=0;i<n;i++){
        scanf("%d",&A[i]);
        if(A[i]<0) cnt++;
        sum+=abs(A[i]);
     }
     if(cnt==n){
        printf("Case %d: inf\n",cas++);
     }
     else{
        int N = n-cnt;
        int g = __gcd(sum,N);
        printf("Case %d: %d/%d\n",cas++,sum/g,N/g);
     }
 
   }
 
return 0;
}