#include<bits/stdc++.h>
using namespace std;
int main()
{
    double n,m,k,p;
    int t,cas=1;
    scanf("%d",&t);
    while(t--){
        scanf("%lf%lf%lf%lf",&n,&m,&k,&p);
        printf("Case %d: %.8lf\n",cas++,n*p*k);
    }
    return 0;
}