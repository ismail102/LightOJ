#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    int m,n;
    int t,cas=1;
    scanf("%d",&t);
    while(t--){

        scanf("%d",&n);

        double ans = 0.0;
        int i=n;
        while(i>=1){

            ans += n/(double)i;
            i--;

        }
        printf("Case %d: %.9lf\n",cas++,ans);
    }

    return  0;

}
