#include<bits/stdc++.h>
using namespace std;
double dp[105];
int ara[105];
int n;
/*double solve(int i)
{
    //cout<<i<<endl;
   if(i>n) return 0;
   //cout<<i<<' '<<n<<endl;
   if(i==n) return ara[n];


   //cout<<dp[i]<<' '<<i<<' '<<n<<endl;

   if(dp[i] != -1) return dp[i];

   //cout<<"   "<<i<<' '<<n<<endl;

   double ans=0.0;
   for(int j=1;j<=6;j++){
       int t = solve(i+j);
       //cout<<ara[i]<<' '<<t<<endl;
       if(t!=0) ans +=ara[i] + t;
       
   }
   //cout<<ans<<endl;
   ans=ans/6.0;

   if(i+6>n){
       int t = 6 - i - 6 + n;
       //cout<<ans<<' '<<6<<'/'<<t<<endl;

       ans = (ans*6)/(double)t;
   }

   return dp[i]=ans;
}*/

int main()
{
    //freopen("input.txt","r",stdin);
    int t,cas=1;
    scanf("%d",&t);
    while(t--){

        scanf("%d",&n);
        for(int i=1;i<=n;i++) scanf("%d",&ara[i]);

        for(int i=0;i<=n;i++) dp[i] = 0;
        
        dp[n]=ara[n];

        for(int i=n-1;i>=1;i--){
            int j;double ans=0;
            //cout<<dp[i+1]<<endl;
            for(j=1;j<=6 and i+j<=n;j++){

                ans+=(ara[i] + dp[i+j])/6.0;
            }
            //cout<<6<<'/'<<j<<' '<<ans<<endl;
            

            ans = ans*6/(double)(j-1);

            dp[i]=ans;

            

        }
        //cout<<dp[1]<<endl;

        printf("Case %d: %.7lf\n",cas++,dp[1]);

    }
    return 0;
}