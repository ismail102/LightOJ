#include<bits/stdc++.h>

using namespace std;

float ara[105][105];

void gauss_solve(int n){
   int i, j, k, mx; double t;
   for(i=0; i<n; i++){
      mx=i;
      for(j=i+1; j<n; j++)
         if(ara[j][i]>ara[mx][i]) mx=j;
      for(j=0; j<n+1; j++){
         t=ara[mx][j];
         ara[mx][j]=ara[i][j];
         ara[i][j]=t;
      }
      for(j=n; j>=i; --j)
      for(k=i+1; k<n; ++k)
         ara[k][j]-=ara[k][i]/ara[i][i]*ara[i][j];
   }
   for(i=n-1; i>=0; i--){
      ara[i][n]=ara[i][n]/ara[i][i];
      ara[i][i]=1;
      for(j=i-1; j>=0; --j){
         ara[j][n]-=ara[j][i]*ara[i][n];
         ara[j][i]=0;
      }
   }
}
void matrix()
{

    for(int i=0;i<93;i++){

        for(int j=i;j<=i+6;j++){

            if(i==j) ara[i][j] = 6.0;

            else ara[i][j] = -1.0;
        }
    }

    for(int i=94,k=1,c=6;i<99;i++,k++,c++){

        for(int j=i;j<=i+6-k;j++){

            if(i==j){ara[i][j]=(float)(6-k);}
            else ara[i][j]=-1.0;
        }

    }
    ara[99][99]=1.0;
}

int main()
{

    int t,n;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        int a,b;

            for(int i=0;i<102;i++){
                for(int j=0;j<102;j++) ara[i][j]=0;
            }

        for(int i=0;i<99;i++) ara[i][100] = 6.0;

        matrix();

        for(int i=0;i<n;i++){
            scanf("%d%d",&a,&b);

            for(int i=0;i<=100;i++) ara[a-1][i]=0.0;

            ara[a-1][b-1] = -1.0;
            ara[a-1][a-1] = 1.0;

        }

       gauss_solve(100);

        for(int i=0;i<100;i++){

            for(int j=0;j<101;j++){
                printf("%f ",ara[i][j]);

            }
            cout<<endl;
        }

    }

return 0;

}
