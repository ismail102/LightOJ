///মো: ইসমাইল হোসাইন(মুকুল)
///বিসমিল্লাহির  রাহমানির রাহিম
#include<bits/stdc++.h>
#define FOR(i, s, e) for(int i=s; i<e; i++)
#define loop(i, n) FOR(i, 0, n)
#define sf scanf
#define pf printf
#define pb push_back
#define MP make_pair
#define fr first
#define sc second
#define ll long long
#define dd double
#define aint(v) v.begin(), v.end()
#define PI acos(-1.0)
#define mem(ara, value) memset(ara, value, sizeof(ara))
#define paii pair<int, int>
#define paint pair<int, int>
#define SZ(a) int(a.size())
#define open() freopen("input.txt", "r", stdin)
#define show() freopen("output.txt", "w", stdout)
using namespace std;
#define Max 100005
vector<int>edge;
int prnt[Max];
int An[Max][25];
int V[Max];
int L[Max];
void sparstable(int n)
{
    memset(An,-1,sizeof(An));

    for(int i=0;i<n;i++) An[i][0] = prnt[i];

    for(int j=1; (1<<j) < n ; j++){
        for(int i=0; i<n; i++){
               if(An[i][j-1] != -1) {
                    An[i][j] = An[An[i][j-1]][j-1];
               }
        }
    }
}

int LCA(int p,int v)
{
    int log=1;

    while(1){

        int next=log+1;
        if((1<<next) > L[p]){
            break;
        }
        log++;
    }

    for(int i=log;i>=0;i--){
        if(An[p][i]!=-1 and V[An[p][i]]>=v){
            p = An[p][i];
        }
    }
    return p;
}
int main()
{
    //freopen("input.txt","r",stdin);
    int n,q,cas=1;
    int t;
    scanf("%d",&t);
    while(t--){
        scanf("%d%d",&n,&q);
        int u;
        int v;
        memset(L,0,sizeof(L));
        L[0]=0;
        V[0]=1;
        prnt[0] = -1;
        for(int i=1;i<n;i++){
            scanf("%d%d",&u,&v);
            prnt[i] = u;
            V[i] = v;
            L[i] = L[u] + 1;
        }

        sparstable(n);

        int k;
        printf("Case %d:\n",cas++);
        for(int i=0;i<q;i++){
            scanf("%d%d",&k,&v);
            int ans = LCA(k,v);
            printf("%d\n",ans);
        }
    }
    return 0;
}
