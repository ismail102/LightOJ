#include<bits/stdc++.h>
using namespace std;
#define Max 3*500
#define pii pair<int,int>
int tree[500+2][Max];
int ara[500+2][500+2];
map<pii,int>inx;
void Make_tree(int row,int node,int s,int e)
{
    if(s==e){

        tree[row][node] = ara[row][s];
        return;
    }

    int mid = (s+e)/2;

    int left = node<<1;
    int right = left + 1;

    Make_tree(row,left,s,mid);
    Make_tree(row,right,mid+1,e);

    tree[row][node] = max(tree[row][left],tree[row][right]);

}
int query(int row,int node,int s,int e,int i,int j)
{
    if(s>j or e<i){

        return -1;
    }
    if(s>=i and e<=j){

        return tree[row][node];
    }
    int mid = (s+e)/2;
    int left = node<<1;
    int right = left + 1;
    int a = query(row,left,s,mid,i,j);
    int b = query(row,right,mid+1,e,i,j);

    return max(a,b);
}

int main()
{
    int n,t,cas=1;

    int m;
    scanf("%d",&t);
    while(t--){

        int s,x,k=0;
        scanf("%d%d",&n,&m);

        for(int i=1;i<=n;i++){

            for(int j=1;j<=n;j++){

                scanf("%d",&ara[i][j]);
            }
        }
        for(int i=1;i<=n;i++){

            Make_tree(i,1,1,n);
        }

        int u,v;
         printf("Case %d:\n",cas++);
        for(int i=0;i<m;i++){

            scanf("%d%d%d",&u,&v,&s);
            int ans=0;
            for(int j=u;j<=u+s-1;j++){
                int mx = query(j,1,1,n,v,v+s-1);
                ans=max(ans,mx);

            }
           printf("%d\n",ans);

        }
    }
return 0;
}
