#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define pii Pair<int,int>
#define ll long long
#define pb push_back
vector<int>edge[Max],cost[Max];
int rep[50005];
int L[Max];
int prnt[Max];
int dng[Max];
int danger[Max][25];
int An[Max][25];
int k=1;
struct st
{
    int u,v;
    int w;

}Link[Max];

bool cmp(st a, st b)
{
    if(a.w<b.w) return true;
    return false;
}
int Find(int r)
{
    if(rep[r]==r) return r;
    rep[r] = Find(rep[r]);
    return rep[r];
}

void MST(int m,int n)
{
    int cnt=0;
    for(int i=0;i<m;i++){

        int u = Find(Link[i].u);
        int v = Find(Link[i].v);

        if(u!=v){
            rep[u]=v;
           // cout<<u<<' '<<v<<endl;
            edge[Link[i].u].pb(Link[i].v);
            edge[Link[i].v].pb(Link[i].u);
            cost[Link[i].u].pb(Link[i].w);
            cost[Link[i].v].pb(Link[i].w);
            cnt++;
            if(cnt==n-1) return;
        }
    }
}
void dfs(int f,int u,int d,int dis){

     prnt[u] = f;
     dng[u] = dis;

     L[u] = d;

    for(int i=0;i<edge[u].size();i++){
        int v = edge[u][i];
        int vcost = cost[u][i];
        if(v==f) continue;
        dfs(u,v,d+1,vcost); 

    }
}

int sparsetable(int n)
{
    memset(An,-1,sizeof(An));

    prnt[0] = -1;
    dng[0] = -1;

    for(int i=0;i<n;i++){
        An[i][0] = prnt[i];
        danger[i][0] = dng[i];
    }

    /*for(int i=0;i<n;i++){
        cout<<i<<"==>"<<prnt[i]<<endl;
    }*/

    for(int j=1; (1<<j)<n; j++){
        for(int i=0;i<n;i++){
            if(An[i][j-1]!=-1){
                An[i][j] = An[An[i][j-1]][j-1];
                danger[i][j] = max(danger[An[i][j-1]][j-1],danger[i][j-1]); 
            }
        }
    }
}

int LCA(int p,int q)
{
    int log;
    if(L[p]<L[q]) swap(p,q);

    log=1;
    while(1){
        int next=log+1;
        if((1<<next) > L[p]) break;
        log++;
    }
    int maxp=-1,maxq=-1;

    for(int i=log;i>=0;i--){
        if(L[p] - (1<<i) >= L[q]){

            maxp = max(maxp,danger[p][i]);
            p = An[p][i];

        }
    }
   // cout<<"p = "<<p<<' '<<"q = "<<q<<endl;

    if(p==q) return maxp;

    for(int i = log; i>=0; i--){

            if(An[p][i]!=-1 and An[p][i]!=An[q][i]){
                maxp = max(maxp,danger[p][i]);
                maxq = max(maxq,danger[q][i]);
                p = An[p][i];
                q = An[q][i]; 
            }
    }

    maxp = max(maxp, dng[p]);
    maxq = max(maxq, dng[q]);

    //cout<<prnt[p];

    return max(maxp,maxq); 


}

int main()
{
    //freopen("input.txt","r",stdin);
    int n,m,cas=1;
    int t;
    scanf("%d",&t);
    while(t--){

        

        scanf("%d%d",&n,&m);

        for(int i=0;i<=n;i++){
            edge[i].clear();
            cost[i].clear();
            prnt[i] = -1;
            dng[i] = -1;
        }

        for(int i=0;i<m;i++){

            scanf("%d%d%d",&Link[i].u,&Link[i].v,&Link[i].w);
            Link[i].u--;
            Link[i].v--;
        }

        for(int i=0;i<n;i++) rep[i] = i;

        sort(Link,Link+m,cmp);

        MST(m,n);

        dfs(-1,0,0,-1);

       sparsetable(n);

        int q,u,v;
        scanf("%d",&q);
        printf("Case %d:\n",cas++);
        for(int i=0;i<q;i++){
            scanf("%d%d",&u,&v);
            int ans = LCA(--u,--v);
            printf("%d\n",ans);
        }

    }
    return 0;
}