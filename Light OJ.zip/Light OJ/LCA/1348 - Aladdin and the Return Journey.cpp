#include<bits/stdc++.h>
using  namespace std;
#define Max 100005
#define ll long long
#define pb push_back
#define pii pair<int,int>
vector<int>edge[Max];
int chainHead[Max],chainIdx[Max];
int posInBase[Max];
int tree[Max*4];
int baseArray[Max];
int An[Max][25];
int L[Max];
int genie[Max];
int subsize[Max];
int pos,chainNo;
void dfs(int f,int u,int d )
{
    An[u][0]=f;
    L[u]=d;
    subsize[u]=1;
    for(int i=0;i<edge[u].size();i++){

        int v = edge[u][i];
        if(v!=f){
            dfs(u,v,d+1);
            subsize[u]+=subsize[v];
        }
    }
}

void HLD(int curNode,int f)
{
    if(chainHead[chainNo]==-1){
        chainHead[chainNo]=curNode;
    }
    ++pos;
    chainIdx[curNode] = chainNo;
    posInBase[curNode]=pos;
    baseArray[pos]=genie[curNode];

    int sc = -1,maxsize=-1;

    for(int i=0;i<edge[curNode].size();i++){
        if(maxsize<subsize[edge[curNode][i]] and f!=edge[curNode][i]){
            maxsize  = subsize[edge[curNode][i]];
            sc=  edge[curNode][i];
        }
    }

    if(sc!=-1){
        HLD(sc,curNode);
    }

    for(int i=0;i<edge[curNode].size();i++){

        if(edge[curNode][i]!=f and edge[curNode][i]!=sc){
            ++chainNo;
            HLD(edge[curNode][i],curNode);
        }
    }

}

int sparsetable(int n)
{
    An[0][0]=-1;
    for(int j=1;(1<<j) < n; j++){
        for(int i=0;i<n;i++){
            if(An[i][j-1]!=-1){
                An[i][j]=An[An[i][j-1]][j-1];
            }
        }
    }
}

int LCA(int p,int q)
{
    if(L[p]<L[q]) swap(p,q);

    int log=1;
    while(1){
        int next = log+1;
        if((1<<next) > L[p])break;
        log++;
    }

    for(int i =log; i>=0;i--){
        if(L[p]- (1<<i) >= L[q]){
            p = An[p][i];
        }
    }

    if(p==q) return p;

    for(int i = log; i>=0; i--){
        if(An[p][i] !=-1 and An[p][i]!=An[q][i]){
            p = An[p][i];
            q = An[q][i];
        }
    }

    return An[p][0];
}

void Make_tree(int node,int s,int e)
{
    if(s==e){
        tree[node]=baseArray[s];
        return;
    }

    int mid = (s+e)/2;

    int left = node<<1;
    int right=  left+1;

    Make_tree(left,s,mid);
    Make_tree(right,mid+1,e);

    tree[node] = tree[left] + tree[right];
}

int query_tree(int node,int s,int e,int i,int j)
{
    if(s>j or e<i){
        return 0;
    }
    if(s>=i and e<=j) return tree[node];

    int mid= (s+e)/2;

    int left = node<<1;
    int right = left+1;
    int l = query_tree(left,s,mid,i,j);
    int r = query_tree(right,mid+1,e,i,j);

    return (l+r);
}

void update(int node,int s,int e,int i,int v)
{
    if(s>i or e<i){
        return;
    }
    if(s==i and e==i){
        tree[node]=v;
        return;
    }

    int mid= (s+e)/2;

    int left = node<<1;
    int right = left+1;
    update(left,s,mid,i,v);
    update(right,mid+1,e,i,v);

    tree[node] = tree[left] + tree[right];

}

int query_up(int lca,int u)
{
    int uchain = chainIdx[u];
    int vchain = chainIdx[lca];

    int sum=0;

    while(1){
        //cout<<"uchain = "<<uchain<<' '<<" lca_chain = "<<vchain<<' '<<" Head = "<<chainHead[uchain]<<" "<<"u =  "<<u<<endl;
      // cout<<"lca = "<<lca<<' '<<"u = "<<u<<endl;
      // cout<<"lca_pos = "<<posInBase[lca]<<' '<<"u_pos = "<<posInBase[u]<<endl;
        if(uchain==vchain){
            int ans=query_tree(1,1,pos,posInBase[lca],posInBase[u]);
            sum+=ans;
           // cout<<"sum1 = "<<sum<<endl;
            break;
        }
        else{
            int head = chainHead[uchain];
            int ans=query_tree(1,1,pos,posInBase[head],posInBase[u]);
            sum+=ans;
            u = An[head][0];
            uchain = chainIdx[u]; 
           // cout<<"sum2 = "<<ans<<endl;
        }
    }
    ///cout<<"sum = "<<sum<<endl;

    return sum;

}
int query(int u,int v)
{
    int lca = LCA(u,v);
    int sum=0,sub=0;
    if(lca==u and lca!=v){
        sum+=query_up(lca,v);
    }
    else if(lca==v and lca!=u){
        sum+=query_up(lca,u);
    }
    else{
        sum+=query_up(lca,u);
        sum+=query_up(lca,v);
        sub = query_tree(1,1,pos,posInBase[lca],posInBase[lca]);
    }
    return sum-sub;
}
int main()
{
   // freopen("input.txt","r",stdin);
   // freopen("output.txt","w",stdout);
    int t,cas=1;

    scanf("%d",&t);
    while(t--){
        int n;
        scanf("%d",&n);
        for(int i=0;i<=n;i++){
            edge[i].clear();
            chainHead[i]=-1;
            subsize[i]=0;
        }
        memset(An,-1,sizeof(An));

        for(int i=0;i<n;i++) scanf("%d",&genie[i]);

        int u,v;
        for(int i=1;i<n;i++){
            scanf("%d%d",&u,&v);
            edge[u].pb(v);
            edge[v].pb(u);
        }

       chainNo=1;
       pos = 0;
        dfs(-1,0,0);
        HLD(0,-1);
       Make_tree(1,1,pos);
       sparsetable(n);
      /* for(int i=0;i<n;i++) cout<<i<<' ';
       cout<<endl;
       for(int i=0;i<n;i++){
           cout<<posInBase[i]<<' ';
       }
       cout<<endl;
       for(int i=1;i<=pos;i++){
           cout<<baseArray[i]<<' ';
       }
       cout<<endl;*/
       int q,f;
       printf("Case %d:\n",cas++);
       scanf("%d",&q);
       for(int i=0;i<q;i++){
           scanf("%d%d%d",&f,&u,&v);
           if(f==0){
               int ans = query(u,v);
               printf("%d\n",ans);
           }
           else{
                update(1,1,pos,posInBase[u],v);
           }
       }
    }

    return 0;
}