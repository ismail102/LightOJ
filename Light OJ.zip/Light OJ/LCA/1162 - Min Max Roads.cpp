#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define Max 100005
#define pb push_back
#define inf 1000000007
vector<pii>edge[Max];
int cost[Max];
int prnt[Max];
int costmax[Max][25];
int costmin[Max][25];
int An[Max][25];
int L[Max];
void input(int n)
{
    int u,v,w;
    for(int i=0;i<=n;i++){
        edge[i].clear();
        prnt[i]=-1;
        cost[i]=-1;
    }
    for(int i=0;i<n-1;i++){
        scanf("%d%d%d",&u,&v,&w);
        --u,--v;
        edge[u].pb(pii(v,w));
        edge[v].pb(pii(u,w));
    }

}
void dfs(int f,int u,int d,int cst)
{
    L[u]=d;
    prnt[u]=f;
    cost[u]=cst;
    for(int i=0;i<edge[u].size();i++){
        pii vv = edge[u][i];

        int v = vv.first,vcost = vv.second;

        if(v==f) continue;
        dfs(u,v,d+1,vcost);
    }
}
void sparsetable(int n)
{
    memset(An,-1,sizeof(An));
    memset(costmax,-1,sizeof(costmax));
    
    for(int j=0; (1<<j) < n; j++){
        for(int i=0;i<n;i++){
            costmin[i][j]=1000000007;
            costmax[i][j]=-1;
        }
    }

    for(int i=0;i<n;i++){
        An[i][0]=prnt[i];
        costmax[i][0] = cost[i];
        costmin[i][0] = cost[i];
    }

    for(int j=1; (1<<j) < n; j++){

        for(int i=0;i<n;i++){
            if(An[i][j-1]!=-1){
                An[i][j]=An[An[i][j-1]][j-1];
                costmax[i][j] = max(costmax[i][j-1],costmax[An[i][j-1]][j-1]);

                costmin[i][j] = min(costmin[i][j-1],costmin[An[i][j-1]][j-1]);
            }
        }
    }

}
pii LCA(int p,int q)
{
    int log;
    if(L[p]<L[q]) swap(p,q);
    log=1;
    while(1){
        int next=log+1;
        if((1<<next) > L[p])break;
        log++;
    }

    int maxp=-1,maxq=-1,minp=1000000007,minq=1000000007;
    for(int i=log;i>=0;i--){

        if(L[p] - (1<<i) >= L[q]){

            maxp = max(maxp,costmax[p][i]);
            minp = min(minp,costmin[p][i]);
            p = An[p][i];
        }
    }
    if(p==q) return pii(maxp,minp);

    for(int i=log;i>=0;i--){
        if(An[p][i]!=-1 and An[p][i]!=An[q][i]){
            maxp = max(maxp,costmax[p][i]);
            maxq = max(maxq,costmax[q][i]);
            minp = min(minp,costmin[p][i]);
            minq = min(minq,costmin[q][i]);

            p = An[p][i];
            q = An[q][i];
        }
    }
    maxp = max(maxp,cost[p]);
    minp = min(minp,cost[p]);

    maxq = max(maxq,cost[q]);
    minq = min(minq,cost[q]);
    return pii(max(maxp,maxq),min(minp,minq));
}
int main()
{
    //freopen("input.txt","r",stdin);
    int n,m;
    int t,cas=1;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        input(n);
        int q;
        dfs(-1,0,0,-1);
        sparsetable(n);
        scanf("%d",&q);
        printf("Case %d:\n",cas++);
        int u,v;
        for(int i=0;i<q;i++){
            scanf("%d%d",&u,&v);
            --u,--v;
            pii ans = LCA(u,v);
            int a=ans.second,b=ans.first;
            if(ans.first==-1 and ans.second!=1000000007){
                a = ans.second,b=0;
            }
            else if(ans.first!=-1 and ans.second==1000000007){
                a = 0,b = ans.first;
            }
            else if(ans.first==-1 and ans.second==1000000007){
                a = 0,b=0;
            }
            printf("%d %d\n",a,b); 
            
        }

    }
}
