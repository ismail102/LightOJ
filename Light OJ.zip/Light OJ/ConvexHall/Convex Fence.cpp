#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define PI acos(-1)
#define Max 5*10000 + 5
struct Point{

    ll x,y;
}P[Max],CH[Max],pp;

ll dist(Point a,Point b)
{
    return (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y);
}

ll cross(Point a,Point o,Point b)
{
    return (a.x - o.x)*(b.y - o.y) - (a.y - o.y)*(b.x - o.x);
}

bool compare_position(Point a,Point b)
{
    return (a.y < b.y) or (a.y==b.y and a.x < b.x);
}

bool compare_angle(Point a,Point b)
{
    ll c = cross(pp,a,b);
    return (c>0) or (c==0 and dist(pp,a) < dist(pp,b));
}
int Graham_scan(int n)
{

    swap(P[0],*min_element(P,P+n,compare_position));

    pp = P[0];

    sort(P+1,P+n,compare_angle);

    P[n]=P[0];

    int j=0;

    for(int i=0;i<=n;i++){
        while(j>=2 and cross(CH[j-2],CH[j-1],P[i]) < 0) j--;
        CH[j++] = P[i];
    }
    return j;

}
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        freopen("output.txt","w",stdout);
    #endif // ONLINE_JUDGE

    int n,t,d,cas=1;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d",&n,&d);
        for(int i=0;i<n;i++){
            scanf("%lld %lld",&P[i].x,&P[i].y);
        }

        int np = Graham_scan(n);
        double para=0.0;

        if(n<=3){
            P[n] = P[0];
            for(int i=1;i<=n;i++){
            //cout<<sqrt(dist(CH[i-1],CH[i]))<<endl;
                para += sqrt(dist(P[i-1],P[i]));
            }
        }
       else{
            for(int i=1;i<np;i++){
               // cout<<sqrt(dist(CH[i-1],CH[i]))<<endl;
                para += sqrt(dist(CH[i-1],CH[i]));
            }

       }
        printf("Case %d: %.8lf\n",cas++,(double)para + 2.0*PI*(double)d);
    }
    return 0;
}
