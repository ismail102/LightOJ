#include<bits/stdc++.h>
using namespace std;
#define PI acos(-1)
#define Max 2 * 1005
#define ll long long
#define eps 0.0000001
struct Point
{
    int x,y,idx;
    int mn,mx;
    double theta;

    
}P[Max];


double tangent(Point a,Point b)
{
    if(abs(b.x - a.x)==0) return (PI/2.0);
    return atan((b.y - a.y)/(double)(b.x - a.x));
}

int cross(Point a,Point o,Point b)
{
    return (a.x - o.x)*(b.y - o.y) - (a.y - o.y)*(b.x - o.x);
}

int dist(Point a,Point b)
{

    return (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y);
}

bool compare_angle(Point a,Point b)
{

    //return  (tangent(P[0],a) < tangent(P[0],b)) or ( tangent(P[0],a) == tangent(P[0],b) and (dist(P[0],a) < dist(P[0],b)));

    int c = cross(P[0],a,b);

    return (c<0) or (c==0 and dist(P[0],a) < dist(P[0],b));
}

bool compare_position(Point a,Point b)
{
    return (a.y < b.y) or (a.y == b.y and a.x < b.x);
}

int main()
{
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
    int t,cas=1;
    int n;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);

        for(int i=0;i<n;i++){
            scanf("%d %d",&P[i].x,&P[i].y);
            P[i].idx = i;
        }

        swap(P[0],*min_element(P,P+n,compare_position));

        sort(P+1,P+n,compare_angle);

        P[0].theta=0.0;
        for(int i=1;i<n;i++){
            //printf("(%d, %d)\n",P[i].x,P[i].y);
            P[i].theta = tangent(P[0],P[i]);

        }

        int cnt=0;

        for(int i=0;i<n;i++){
            //printf("(%d,%d)==%lf\n",P[i].x,P[i].y,P[i].theta);

            if(cross(P[i],P[(i+1)%n],P[(i+2)%n])==0){
                //cout<<i<<' '<<(i+1)%n<<' '<<(i+2)%n<<endl;;
               // cout<<cross(P[i],P[(i+1)%n],P[(i+2)%n])<<endl;
               cnt++;
            }
        }

        printf("Case %d:\n",cas++);
        //cout<<cnt<<endl;
        if(cnt==n or n<=2){
            printf("Impossible\n");
            continue;
        }

        int pos = 0;
        for(int i=n-2;i>0;i--){

            int c = cross(P[0],P[n-1],P[i]);
            //cout<<c<<endl;
            if(abs(c) > 0){
                pos = i;
                break;
            }
        }

        reverse(P + pos + 1,P + n);

       //for(int i=0;i<n;i++) printf("(%d, %d) == %d\n",P[i].x,P[i].y,P[i].idx);

        for(int i=0;i<n;i++){
            if(i==0) printf("%d",P[i].idx);
            else printf(" %d",P[i].idx);
        }

        printf("\n");

    }

    return 0;

}
