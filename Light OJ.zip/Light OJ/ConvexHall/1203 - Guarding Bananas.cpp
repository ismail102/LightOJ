
#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define PI acos(-1)
#define ll long long
struct Point
{
    ll x,y;
    double ang;
}P[Max],CH[Max],pp;
double dist(Point a,Point b)
{
    return (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y);
}
double angle(Point a,Point o,Point b)
{
    Point A,B;
    A.x = (a.x - o.x);
    A.y = (a.y - o.y);
    B.x = (b.x - o.x);
    B.y = (b.y - o.y);

    double aa = A.x*B.x;
    double bb = A.y*B.y;

    double dot = aa + bb;

    if(dot==0) return acos(dot);

    double ax = A.x*A.x;
    double ay = A.y*A.y;

    double bx = B.x*B.x;
    double by = B.y*B.y;

    double temp1 = sqrt(ax + ay);
    double temp2 = sqrt(bx + by);
    double temp = temp1*temp2;
    double theta = (dot/temp);
    
    return acos(theta);

}
double cross(Point o,Point a,Point b)
{
    return ((a.x - o.x)*(b.y - o.y) - (a.y - o.y)*(b.x - o.x));
}
double compare_position(Point a,Point b)
{
    return (a.x<b.x) or (a.x==b.x and a.y<b.y);
}
double compare_angle(Point a,Point b)
{
    double c = cross(pp,a,b);
    return (c>0 or (c==0 and dist(pp,a) < dist(pp,b)));
}

int Graham_scan(int n)
{
    swap(P[0],*min_element(P,P+n,compare_position));
    pp = P[0];
    sort(P+1,P+n,compare_angle);
    P[n] = P[0];
    int j=0;
    for(int i=0;i<=n;i++){
        while(j>=2 and cross(CH[j-2],CH[j-1],P[i]) <= 0) j--;
        CH[j++] = P[i];
    }
    CH[j++] = CH[1];
    return j;
}
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif

    int t;
    int n,cas=1;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(int i=0;i<n;i++){
            scanf("%lld %lld",&P[i].x,&P[i].y);
        }
        if(n==1 or n==2){
            printf("Case %d: %.7lf\n",cas++,(double)0);
            continue;
        }
        bool f=true;
        for(int i=0;i<n;i++){
            if(i+2<n and cross(P[i],P[i+1],P[i+2])!=0){
                f=false;
                break;
            }
        }
        if(f){
            printf("Case %d: %.7lf\n",cas++,(double)0);
        }
        else{
            int np = Graham_scan(n);
            double mn = 1000000007.0;
            for(int i=0;i<np;i++){
                double theta;
                if(i+2<np){

                    theta = angle(CH[i],CH[i+1],CH[i+2]);

                    //cout<<"( "<<CH[i].x<<","<<CH[i].y<<" )<==>( "<<CH[i+1].x<<","<<CH[i+1].y<<" )<==>( "<<CH[i+2].x<<","<<CH[i+2].y<<" )\n";

                    //cout<<theta<<endl;
                    mn = min(mn,(theta*180.0/PI));
                    //printf("%.7lf\n",(theta*180.0/PI));
                }
            }
            //cout<<endl;

            printf("Case %d: %.7lf\n",cas++,mn);
            //cout<<endl;

        }


    }
}